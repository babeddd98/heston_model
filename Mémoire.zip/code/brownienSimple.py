import numpy as np
import matplotlib.pyplot as plt

n = 5000                # nombre de points simules
t = 1                   # nombre de dimensions 
sigma = np.sqrt(t/n)    # ecart-type

y=[0]
y = sigma*np.random.randn(n) # VA normalement distribuees
y = np.cumsum(y)             # somme cumulative des yi

x = [i for i in range(n)]      

plt.plot(x, y, color='red', lw=1) 
plt.xlabel("temps t")
plt.grid(axis='y',linestyle='dotted', color='b')
plt.show()